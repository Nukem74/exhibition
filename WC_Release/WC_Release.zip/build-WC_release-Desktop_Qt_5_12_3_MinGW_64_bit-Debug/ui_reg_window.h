/********************************************************************************
** Form generated from reading UI file 'reg_window.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REG_WINDOW_H
#define UI_REG_WINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_reg_window
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *labelWelcome;
    QLineEdit *confirmLineEdit;
    QLineEdit *passwordLineEdit;
    QLabel *label_Confirm;
    QLineEdit *nameLineEdit;
    QLabel *label_Name;
    QLabel *label_Pass;
    QPushButton *registerPushButton;

    void setupUi(QWidget *reg_window)
    {
        if (reg_window->objectName().isEmpty())
            reg_window->setObjectName(QString::fromUtf8("reg_window"));
        reg_window->resize(269, 184);
        gridLayoutWidget = new QWidget(reg_window);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(0, 0, 211, 141));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        labelWelcome = new QLabel(gridLayoutWidget);
        labelWelcome->setObjectName(QString::fromUtf8("labelWelcome"));
        labelWelcome->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelWelcome, 0, 1, 1, 1);

        confirmLineEdit = new QLineEdit(gridLayoutWidget);
        confirmLineEdit->setObjectName(QString::fromUtf8("confirmLineEdit"));

        gridLayout->addWidget(confirmLineEdit, 3, 1, 1, 1);

        passwordLineEdit = new QLineEdit(gridLayoutWidget);
        passwordLineEdit->setObjectName(QString::fromUtf8("passwordLineEdit"));

        gridLayout->addWidget(passwordLineEdit, 2, 1, 1, 1);

        label_Confirm = new QLabel(gridLayoutWidget);
        label_Confirm->setObjectName(QString::fromUtf8("label_Confirm"));
        label_Confirm->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_Confirm, 3, 0, 1, 1);

        nameLineEdit = new QLineEdit(gridLayoutWidget);
        nameLineEdit->setObjectName(QString::fromUtf8("nameLineEdit"));

        gridLayout->addWidget(nameLineEdit, 1, 1, 1, 1);

        label_Name = new QLabel(gridLayoutWidget);
        label_Name->setObjectName(QString::fromUtf8("label_Name"));
        label_Name->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_Name, 1, 0, 1, 1);

        label_Pass = new QLabel(gridLayoutWidget);
        label_Pass->setObjectName(QString::fromUtf8("label_Pass"));
        label_Pass->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_Pass, 2, 0, 1, 1);

        registerPushButton = new QPushButton(gridLayoutWidget);
        registerPushButton->setObjectName(QString::fromUtf8("registerPushButton"));

        gridLayout->addWidget(registerPushButton, 4, 1, 1, 1);


        retranslateUi(reg_window);

        QMetaObject::connectSlotsByName(reg_window);
    } // setupUi

    void retranslateUi(QWidget *reg_window)
    {
        reg_window->setWindowTitle(QApplication::translate("reg_window", "Form", nullptr));
        labelWelcome->setText(QApplication::translate("reg_window", "Register yourself", nullptr));
        label_Confirm->setText(QApplication::translate("reg_window", "Confirm :", nullptr));
        label_Name->setText(QApplication::translate("reg_window", "Name: ", nullptr));
        label_Pass->setText(QApplication::translate("reg_window", "Password :", nullptr));
        registerPushButton->setText(QApplication::translate("reg_window", "Register", nullptr));
    } // retranslateUi

};

namespace Ui {
    class reg_window: public Ui_reg_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REG_WINDOW_H
