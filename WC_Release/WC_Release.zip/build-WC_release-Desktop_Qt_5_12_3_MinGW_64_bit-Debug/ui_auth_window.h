/********************************************************************************
** Form generated from reading UI file 'auth_window.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUTH_WINDOW_H
#define UI_AUTH_WINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_auth_window
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *label_Password;
    QLabel *label_Name;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QPushButton *loginPushButton;
    QLabel *labelWelcome;
    QPushButton *registerPushButton_2;

    void setupUi(QWidget *auth_window)
    {
        if (auth_window->objectName().isEmpty())
            auth_window->setObjectName(QString::fromUtf8("auth_window"));
        auth_window->resize(302, 191);
        gridLayoutWidget = new QWidget(auth_window);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(0, 0, 241, 151));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_Password = new QLabel(gridLayoutWidget);
        label_Password->setObjectName(QString::fromUtf8("label_Password"));
        label_Password->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_Password, 2, 0, 1, 1);

        label_Name = new QLabel(gridLayoutWidget);
        label_Name->setObjectName(QString::fromUtf8("label_Name"));
        label_Name->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_Name, 1, 0, 1, 1);

        lineEdit = new QLineEdit(gridLayoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        gridLayout->addWidget(lineEdit, 1, 1, 1, 1);

        lineEdit_2 = new QLineEdit(gridLayoutWidget);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        gridLayout->addWidget(lineEdit_2, 2, 1, 1, 1);

        loginPushButton = new QPushButton(gridLayoutWidget);
        loginPushButton->setObjectName(QString::fromUtf8("loginPushButton"));

        gridLayout->addWidget(loginPushButton, 3, 1, 1, 1);

        labelWelcome = new QLabel(gridLayoutWidget);
        labelWelcome->setObjectName(QString::fromUtf8("labelWelcome"));
        labelWelcome->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelWelcome, 0, 1, 1, 1);

        registerPushButton_2 = new QPushButton(gridLayoutWidget);
        registerPushButton_2->setObjectName(QString::fromUtf8("registerPushButton_2"));

        gridLayout->addWidget(registerPushButton_2, 4, 1, 1, 1);


        retranslateUi(auth_window);

        QMetaObject::connectSlotsByName(auth_window);
    } // setupUi

    void retranslateUi(QWidget *auth_window)
    {
        auth_window->setWindowTitle(QApplication::translate("auth_window", "Form", nullptr));
        label_Password->setText(QApplication::translate("auth_window", "Password :", nullptr));
        label_Name->setText(QApplication::translate("auth_window", "Name :", nullptr));
        loginPushButton->setText(QApplication::translate("auth_window", "Log In", nullptr));
        labelWelcome->setText(QApplication::translate("auth_window", "Authentificate yourself", nullptr));
        registerPushButton_2->setText(QApplication::translate("auth_window", "Register", nullptr));
    } // retranslateUi

};

namespace Ui {
    class auth_window: public Ui_auth_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUTH_WINDOW_H
